import { ConnectionOptions } from "bullmq";

export const defaultConnection: ConnectionOptions = {
  host: "localhost",
  port: 6379,
};
